from flask import Flask, request, send_file, render_template
import os, uuid
from gpt1_pointillist_stego import encode

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def home():
    return render_template('index.html')  # Serve your main page

@app.route('/encode', methods=['POST'])
def encode_image():
    file = request.files['image']
    filename = os.path.join(UPLOAD_FOLDER, str(uuid.uuid4()) + '.png')
    file.save(filename)

    output_filename = filename.replace('.png', '_encoded.png')
    args = type('Args', (), {
        'src': filename,
        'out': output_filename,
        'bits': 8,
        'zstd': 22,
        'dots': None,
        'jitter': 6,
        'radius': 1,
        'cache': os.path.expanduser("~/.cache/gpt1_stego")
    })()

    encode(args)
    return send_file(output_filename, mimetype='image/png')

if __name__ == '__main__':
    app.run(debug=True) # Run the Flask app in debug mode